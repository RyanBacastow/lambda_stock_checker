# lambda_stock_checker
This app will be designed to retrieve stock index price and other asset price information for building out a reverse momentum buying strategy (buy and hold strategy for bear markets) using AWS Lambda, DynamoDB, and AWS SNS.
